package com.example.transporttracker;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import android.app.PendingIntent;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.Manifest;
import android.os.IBinder;
import android.support.annotation.NonNull;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;

public class TrackerService extends Service {

    private static final String TAG = TrackerService.class.getSimpleName();
    private FirebaseAuth mAuth;
    int p_Count;
    Boolean status = false;
    Location location;
    String uid;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate(){
        super.onCreate();
        buildNotification();
        mAuth = FirebaseAuth.getInstance();
        loginToFirebase();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    private void buildNotification() {

        String stop = "stop";
        registerReceiver(stopReceiver, new IntentFilter(stop));
        PendingIntent broadcastIntent = PendingIntent.getBroadcast(
                this, 0, new Intent(stop), PendingIntent.FLAG_UPDATE_CURRENT);
        //Create the persistent Notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this,  "notice")
                .setContentTitle(getString(R.string.app_name))
                .setContentTitle(getString(R.string.notification_text))
                .setOngoing(true)
                .setContentIntent(broadcastIntent)
                .setSmallIcon(R.drawable.ic_tracker);
        startForeground(1, builder.build());
    }

    protected BroadcastReceiver stopReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(TAG, "received stop broadcast");
            //Stop the service when the notification is tapped
            unregisterReceiver(stopReceiver);
            stopSelf();
            stopForeground(true);
            onDestroy();
            uid = null;
        }
    };

    @Override
    public void onDestroy()
    {
        // Unregistered or disconnect what you need to
        // For example: mGoogleApiClient.disconnect();

        // Or break the while loop condition
        // mDoWhile = false;

        super.onDestroy();
    }

    private void loginToFirebase() {
        // Functionlity
        String email = getString(R.string.firebase_email);
        String password = getString(R.string.firebase_password);
        mAuth.signInWithEmailAndPassword(
                email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    Log.d(TAG, "firebase auth success");
                    requestLocationUpdates();
                } else {
                    Log.d(TAG, "firebase auth failed");
                }

            }
        });
    }

    public static class local {
        public Object user;
        public Object longitude;
        public Object latitude;
        public int counts;
        public int counter;

        public local (){

        }

        public local (Object longitude, Object latitude){
            this.longitude = longitude;
            this.latitude = latitude;
        }

        public local (int counts, Object longitude, Object latitude, Object user, int counter) {
            this.longitude = longitude;
            this.user = user;
            this.latitude = latitude;
        }
    }

    private void requestLocationUpdates() {

        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null){
            uid = user.getUid();
        }
        //Function
        LocationRequest request = new LocationRequest();
        request.setInterval(10000);
        request.setFastestInterval(5000);
        long test;
        request.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        FusedLocationProviderClient client = LocationServices.getFusedLocationProviderClient(this);
        final String start = getString(R.string.firebase_path) + "/" + uid;
        final String counts = getString(R.string.firebase_path) + "/" + uid + "/counts";
        final String path = getString(R.string.firebase_path) + "/" + getString(R.string.transport_id);
        int permission =  ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);


        if (permission == PackageManager.PERMISSION_GRANTED && user != null) {
            //Request location updates and when an update is
            //received, store the location in Firebase
            client.requestLocationUpdates(request, new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {
                    final DatabaseReference ref = FirebaseDatabase.getInstance().getReference(path);
                    DatabaseReference ref_c = FirebaseDatabase.getInstance().getReference(counts);
                    final DatabaseReference ref_p = FirebaseDatabase.getInstance().getReference(start);
                    Location loca= locationResult.getLastLocation();
                    location = loca;


                    if (location != null ) {
                        ref_p.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                Map<String, Object> postValues = new HashMap<String,Object>();
                                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                    postValues.put(snapshot.getKey(),snapshot.getValue());
                                }
                                try {

                                    long size = dataSnapshot.getChildrenCount();
                                    p_Count = (int) size + 1;
                                } catch (Exception e) {
                                    p_Count = 1;
                                }

                                String z = "" + p_Count;
                                local localUpdate = new local(location.getLongitude(), location.getLatitude());
                                ref_p.child(z).setValue(localUpdate);
                                //postValues.put("latitude", location.getLatitude());
                                //postValues.put("longitude", location.getLongitude());
                                //postValues.put("user/counter", i);
                                //ref_p.updateChildren(postValues);
                                Log.d(TAG, "location" + location);
                                Log.d(TAG, "tagging: " + dataSnapshot.getChildrenCount());
                                status = true;

                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });
                        //ref_c.setValue(5);
                        Log.d(TAG, "location update" + location);
                        if (status) {Log.d(TAG, "db" + p_Count);
                        } else {
                            Log.d(TAG, "db" + null);
                        }
                        //ref.setValue(location);
                    }
                }
            }, null);
        }
    }
}
